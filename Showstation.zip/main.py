import os
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.video import Video
from kivy.core.audio import SoundLoader

class ShowStationApp(App):
    def build(self):
        self.layout_principal = BoxLayout(orientation='vertical', padding=10, spacing=10)

        # Reproductor de video
        self.reproductor = Video(source='', state='stop', options={'eos': 'loop'})
        self.layout_principal.add_widget(self.reproductor)

        # Etiqueta de información
        self.info_label = Label(text="Ninguna pista cargada", size_hint_y=None, height=40)
        self.layout_principal.add_widget(self.info_label)

        # Botón Play / Pausa Video
        btn_play = Button(text="Play / Pausa Video", size_hint_y=None, height=50)
        btn_play.bind(on_press=self.control_reproduccion)
        self.layout_principal.add_widget(btn_play)

        # Botón Siguiente Pista
        btn_siguiente = Button(text="Siguiente Pista", size_hint_y=None, height=50)
        btn_siguiente.bind(on_press=self.cargar_siguiente)
        self.layout_principal.add_widget(btn_siguiente)

        # Contenedor para la botonera de efectos
        self.layout_efectos = BoxLayout(orientation='horizontal', spacing=10, size_hint_y=None, height=60)

        efectos = [
            ("DIANA MARIACHI", "diana 1.mp3", (1, 0.5, 0, 1)),     # Naranja
            ("DIANA SONIDERA", "diana 2.mp3", (1, 0.2, 0.2, 1)),   # Rojo
            ("DIANA BANDA", "diana 3.mp3", (0.5, 0, 1, 1)),      # Morado
            ("MAÑANITAS", "Mananitas.mp3", (0, 0.8, 0.2, 1)),   # Verde
            ("FELICIDADES", "Felicidades.mp3", (0, 0.5, 1, 1))    # Azul
        ]

        for texto, archivo, color in efectos:
            btn_efecto = Button(text=texto, background_color=color, font_size='11sp', bold=True)
            btn_efecto.bind(on_press=lambda x, f=archivo: self.tocar_efecto(f))
            self.layout_efectos.add_widget(btn_efecto)

        self.layout_principal.add_widget(self.layout_efectos)

        # Configuración de rutas de archivos
        base_path = os.path.dirname(os.path.abspath(__file__))
        self.ruta_pistas = os.path.join(base_path, 'pistas')
        self.ruta_efectos = os.path.join(base_path, 'efectos')
        self.ruta_ambiente = os.path.join(base_path, 'ambiente')
        
        self.musica_fondo = None
        self.sonido_efecto = None
        
        # Carga música de ambiente
        if os.path.exists(self.ruta_ambiente):
            archivos_ambiente = os.listdir(self.ruta_ambiente)
            if archivos_ambiente:
                ruta_mix = os.path.join(self.ruta_ambiente, archivos_ambiente[0])
                self.musica_fondo = SoundLoader.load(ruta_mix)
            
        if self.musica_fondo:
            self.musica_fondo.loop = True
            self.musica_fondo.volume = 0.5
            self.musica_fondo.play()           
        
        self.lista_pistas = []
        self.indice = -1
        
        return self.layout_principal

    def control_reproduccion(self, instance):
        if self.reproductor.source == '':
            self.cargar_siguiente(None)
        elif self.reproductor.state == 'play':
            self.reproductor.state = 'pause'
            if self.musica_fondo: 
                self.musica_fondo.volume = 0.5 
        else:
            self.reproductor.state = 'play'
            if self.musica_fondo: 
                self.musica_fondo.volume = 0

    def cargar_siguiente(self, instance):
        if os.path.exists(self.ruta_pistas):
            archivos_validos = [f for f in os.listdir(self.ruta_pistas) if f.lower().endswith(('.mp4', '.avi', '.mkv'))]
            self.lista_pistas = archivos_validos

            if self.lista_pistas:
                self.indice = (self.indice + 1) % len(self.lista_pistas)
                nombre_pista = self.lista_pistas[self.indice]
             
                self.reproductor.source = os.path.join(self.ruta_pistas, nombre_pista)
                self.info_label.text = f"Pista: {nombre_pista}"
                self.reproductor.state = 'play'
            else:
                self.info_label.text = "Error: No hay archivos de video en la carpeta /pistas"

    def tocar_efecto(self, nombre_archivo):
        # 1. Silenciamos el ambiente por completo
        if self.musica_fondo:
            self.musica_fondo.volume = 0.0
        
        # 2. Frenamos cualquier efecto anterior
        if self.sonido_efecto:
            self.sonido_efecto.stop()
            self.sonido_efecto.unload()

        # 3. Pausamos el video si se está reproduciendo
        if self.reproductor.state == 'play':
            self.reproductor.state = 'pause'

        # 4. Cargamos y tocamos el nuevo efecto
        ruta = os.path.join(self.ruta_efectos, nombre_archivo)
        self.sonido_efecto = SoundLoader.load(ruta)
        
        if self.sonido_efecto:
            print(f"Tocando efecto: {nombre_archivo}")
            self.sonido_efecto.volume = 1.0
            
            # Monitoreamos el estado para saber cuándo termina de forma natural
            self.sonido_efecto.bind(state=self.checar_final_efecto)
            self.sonido_efecto.play()
        else:
            print(f"No se encontró el archivo en: {ruta}")
            if self.musica_fondo:
                self.musica_fondo.volume = 0.5
    
    def checar_final_video(self, instance, value):
        if value == 'stop' and self.musica_fondo:
            self.musica_fondo.volume = 0.5

    def checar_final_efecto(self, instance, value):
        # Cuando el audio pasa a 'stop' por sí solo, le regresamos el volumen al fondo
        if value == 'stop':
            if self.musica_fondo:
                self.musica_fondo.volume = 0.5
            print("El efecto terminó solo, regresa el volumen de ambiente.")

if __name__ == '__main__':
    ShowStationApp().run()